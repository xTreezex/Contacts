# Contacts App
You can add new contact, check info, edit or delete an existing one, make a search.

All requests are connected to local server -> db.

Added custom validation on fields: "firstName" and "lastName" during the process of add new contact or editing an existing one (Allowed only use the Latin alphabet for these fields)

## How to run

Type in a terminal `npm run server` for a db server. Open a new terminal window and type `ng serve` to start app. Navigate to `http://localhost:4200/`.

### Use the next credentials:

login: `admin@admin.ru`

password: `admin`
