export class ContactModel {
  id?: number;
  userId?: number;
  firstName: string = '';
  lastName: string = '';
  phone: string = '';
}
